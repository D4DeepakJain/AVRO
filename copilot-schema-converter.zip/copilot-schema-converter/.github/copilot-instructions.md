# Schema conversion workflow

For requests to convert JSON payloads into Java Model Classes and AVSC files, or to add/remove/modify schema fields, use the `Schema Converter` custom agent where agent delegation is supported.

The agent must use `tools/schema_converter.py` rather than hand-calculating schema differences. Default output directory is `generated/`. If the user supplies a JSON file and class name, run:

`python3 tools/schema_converter.py --input <payload.json> --class-name <ClassName> --output-dir generated`

Ask for clarification if the input path or class name is ambiguous. A missing JSON field means deletion only when the payload is confirmed to be a complete schema snapshot, not a partial event.
